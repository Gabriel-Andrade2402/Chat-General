package com.example.web.socket.SocketChat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocketChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
